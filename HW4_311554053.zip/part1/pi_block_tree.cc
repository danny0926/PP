#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, char **argv)
{
    // --- DON'T TOUCH ---
    MPI_Init(&argc, &argv);
    double start_time = MPI_Wtime();
    double pi_result;
    long long int tosses = atoi(argv[1]);
    int world_rank, world_size;
    // ---

    // TODO: MPI init

    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);

    MPI_Status status;
    long long int part_tosses = tosses / world_size;
    unsigned int in_circle = 0, total_in_circle = 0;
    unsigned int seed = time(NULL) * world_rank;
    double x, y, distance;
    int send = 2;

    y = (double)rand_r(&seed) / RAND_MAX;

    // TODO: binary tree redunction

    for(unsigned int i = 0; i < part_tosses; ++i)
    {
    	x = y;
	y = (double)rand_r(&seed) / RAND_MAX;

	distance = x*x + y*y;
	if(distance <= 1)
	       	++total_in_circle;
    }

    while (send <= world_size)
    {
    	if (world_rank % send == 0)
	{
		MPI_Recv(&in_circle, 1, MPI_UNSIGNED, world_rank + send/2, 0, MPI_COMM_WORLD, &status);
		total_in_circle += in_circle;
	}
	else
	{
		MPI_Send(&total_in_circle, 1, MPI_UNSIGNED, world_rank - send/2, 0, MPI_COMM_WORLD);
		break;
	}
	send *= 2;
    }



    if (world_rank == 0)
    {
        // TODO: PI result

	pi_result = 4*total_in_circle / ((double)tosses);

        // --- DON'T TOUCH ---
        double end_time = MPI_Wtime();
        printf("%lf\n", pi_result);
        printf("MPI running time: %lf Seconds\n", end_time - start_time);
        // ---
    }

    MPI_Finalize();
    return 0;
}
