#include<iostream>
#include<iomanip>
#include<cstdlib>
#include<ctime>
#include<algorithm>
#include<math.h>
#include<pthread.h>
#include<immintrin.h>
#include<vector>
#include<numeric>

using namespace std;

int CPU_cores = 4;
long long int tosses = 100000000;
long long int part_tosses = 0;

void *numberInCircle(void *val)
{
	unsigned int seed = time(NULL) + pthread_self();
	int rand_num;

	__m256 _x, _y;

	rand_num = rand_r(&seed);

	for(int i = 0; i < 8; ++i)
	{
		_x[i] = (double)(rand_num & 0xffff) / 0xffff;
		rand_num >> 1;
		_y[i] = (double)(rand_num & 0xffff) / 0xffff;
		rand_num >> 1;
	}
	_x = _mm256_mul_ps(_x, _x);

	long long int temp_num_in_circle = 0;
	
	for(long long int toss = 0; toss < part_tosses; toss += 8)
	{
		_y = _mm256_mul_ps(_y, _y);
		_x = _mm256_add_ps(_x, _y);

		rand_num = rand_r(&seed);
		for(int i = 0; i < 8; ++i)
		{
			if(_x[i] < 1) ++temp_num_in_circle;

			_x[i] = _y[i];
			_y[i] = (float)(rand_num & 0xffff) / 0xffff;
			rand_num >> 2;
		}
	}

	pthread_exit((void*) temp_num_in_circle);

}


float calculatePi()
{
	long long int num_in_circle = 0;
	part_tosses = tosses * 1.2 / CPU_cores;
	part_tosses = part_tosses - part_tosses % CPU_cores;

	pthread_t thread_handles[32];
	for(int thread = 0; thread < CPU_cores; ++thread)
	{
		pthread_create(&thread_handles[thread], NULL, numberInCircle, NULL);
	}

	void *returnValue;
	for(int thread = 0; thread < CPU_cores; ++thread)
	{
		pthread_join(thread_handles[thread], &returnValue);
		num_in_circle  += (long long int) returnValue;
	}

	float pi = 4.0 * num_in_circle / (part_tosses * CPU_cores);

	return pi;
}

int main(int argc, char *argv[])
{
	if(argc == 3)
	{
		CPU_cores = strtol(argv[1], NULL, 10);
		if(CPU_cores < 1) CPU_cores = 1;
		else if(CPU_cores > 32) CPU_cores = 32;

		tosses = strtol(argv[2], NULL, 10);
		if(tosses < 150000000) tosses = 150000000;
	}
	else if(argc != 1) return 1;

	float ans = calculatePi();
	cout << setprecision(8) << ans << endl;
	return 0;
}
